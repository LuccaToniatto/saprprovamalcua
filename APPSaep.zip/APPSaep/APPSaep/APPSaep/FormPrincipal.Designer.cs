﻿namespace APPSaep
{
    partial class FormPrincipal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn10 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn11 = new System.Windows.Forms.Button();
            this.panelBtn = new System.Windows.Forms.Panel();
            this.panelCarros = new System.Windows.Forms.Panel();
            this.btnEscolher = new System.Windows.Forms.Button();
            this.lblarea = new System.Windows.Forms.Label();
            this.lblCarro = new System.Windows.Forms.Label();
            this.lblNumero = new System.Windows.Forms.Label();
            this.cbxCarro = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.cbxConcessionaria = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbxCliente = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblNomeDoCarro = new System.Windows.Forms.Label();
            this.panelBtn.SuspendLayout();
            this.panelCarros.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn10
            // 
            this.btn10.Enabled = false;
            this.btn10.Location = new System.Drawing.Point(389, 60);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(245, 490);
            this.btn10.TabIndex = 0;
            this.btn10.Text = "10";
            this.btn10.UseVisualStyleBackColor = true;
            this.btn10.Click += new System.EventHandler(this.btn10_Click);
            // 
            // btn6
            // 
            this.btn6.Enabled = false;
            this.btn6.Location = new System.Drawing.Point(527, 15);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(107, 47);
            this.btn6.TabIndex = 1;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            // 
            // btn5
            // 
            this.btn5.Enabled = false;
            this.btn5.Location = new System.Drawing.Point(243, 356);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(193, 253);
            this.btn5.TabIndex = 2;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            // 
            // btn3
            // 
            this.btn3.Enabled = false;
            this.btn3.Location = new System.Drawing.Point(79, 389);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(177, 220);
            this.btn3.TabIndex = 3;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            // 
            // btn1
            // 
            this.btn1.Enabled = false;
            this.btn1.Location = new System.Drawing.Point(3, 257);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(155, 222);
            this.btn1.TabIndex = 4;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click_1);
            // 
            // btn2
            // 
            this.btn2.Enabled = false;
            this.btn2.Location = new System.Drawing.Point(294, 292);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(75, 95);
            this.btn2.TabIndex = 5;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            // 
            // btn4
            // 
            this.btn4.Enabled = false;
            this.btn4.Location = new System.Drawing.Point(128, 282);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(128, 130);
            this.btn4.TabIndex = 6;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            // 
            // btn7
            // 
            this.btn7.Enabled = false;
            this.btn7.Location = new System.Drawing.Point(224, 257);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(87, 106);
            this.btn7.TabIndex = 7;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            // 
            // btn9
            // 
            this.btn9.Enabled = false;
            this.btn9.Location = new System.Drawing.Point(270, 144);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(99, 79);
            this.btn9.TabIndex = 8;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            // 
            // btn8
            // 
            this.btn8.Enabled = false;
            this.btn8.Location = new System.Drawing.Point(186, 150);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(87, 58);
            this.btn8.TabIndex = 9;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            // 
            // btn11
            // 
            this.btn11.Enabled = false;
            this.btn11.Location = new System.Drawing.Point(257, 69);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(54, 69);
            this.btn11.TabIndex = 10;
            this.btn11.Text = "11";
            this.btn11.UseVisualStyleBackColor = true;
            // 
            // panelBtn
            // 
            this.panelBtn.BackColor = System.Drawing.Color.Transparent;
            this.panelBtn.Controls.Add(this.btn5);
            this.panelBtn.Controls.Add(this.btn11);
            this.panelBtn.Controls.Add(this.btn10);
            this.panelBtn.Controls.Add(this.btn8);
            this.panelBtn.Controls.Add(this.btn6);
            this.panelBtn.Controls.Add(this.btn9);
            this.panelBtn.Controls.Add(this.btn3);
            this.panelBtn.Controls.Add(this.btn7);
            this.panelBtn.Controls.Add(this.btn1);
            this.panelBtn.Controls.Add(this.btn4);
            this.panelBtn.Controls.Add(this.btn2);
            this.panelBtn.Location = new System.Drawing.Point(41, 28);
            this.panelBtn.Name = "panelBtn";
            this.panelBtn.Size = new System.Drawing.Size(692, 648);
            this.panelBtn.TabIndex = 11;
            // 
            // panelCarros
            // 
            this.panelCarros.Controls.Add(this.btnEscolher);
            this.panelCarros.Controls.Add(this.lblarea);
            this.panelCarros.Controls.Add(this.lblCarro);
            this.panelCarros.Controls.Add(this.lblNumero);
            this.panelCarros.Controls.Add(this.cbxCarro);
            this.panelCarros.Location = new System.Drawing.Point(133, 271);
            this.panelCarros.Name = "panelCarros";
            this.panelCarros.Size = new System.Drawing.Size(386, 122);
            this.panelCarros.TabIndex = 12;
            // 
            // btnEscolher
            // 
            this.btnEscolher.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(20)))), ((int)(((byte)(255)))));
            this.btnEscolher.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnEscolher.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEscolher.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnEscolher.ForeColor = System.Drawing.Color.White;
            this.btnEscolher.Location = new System.Drawing.Point(257, 63);
            this.btnEscolher.Name = "btnEscolher";
            this.btnEscolher.Size = new System.Drawing.Size(113, 33);
            this.btnEscolher.TabIndex = 17;
            this.btnEscolher.Text = "Escolher:";
            this.btnEscolher.UseVisualStyleBackColor = false;
            this.btnEscolher.Click += new System.EventHandler(this.btnEscolher_Click);
            // 
            // lblarea
            // 
            this.lblarea.AutoSize = true;
            this.lblarea.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblarea.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(20)))), ((int)(((byte)(255)))));
            this.lblarea.Location = new System.Drawing.Point(3, 2);
            this.lblarea.Name = "lblarea";
            this.lblarea.Size = new System.Drawing.Size(99, 45);
            this.lblarea.TabIndex = 13;
            this.lblarea.Text = "Área:";
            // 
            // lblCarro
            // 
            this.lblCarro.AutoSize = true;
            this.lblCarro.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCarro.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(20)))), ((int)(((byte)(255)))));
            this.lblCarro.Location = new System.Drawing.Point(3, 44);
            this.lblCarro.Name = "lblCarro";
            this.lblCarro.Size = new System.Drawing.Size(67, 25);
            this.lblCarro.TabIndex = 16;
            this.lblCarro.Text = "Carro:";
            // 
            // lblNumero
            // 
            this.lblNumero.AutoSize = true;
            this.lblNumero.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNumero.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(20)))), ((int)(((byte)(255)))));
            this.lblNumero.Location = new System.Drawing.Point(93, 2);
            this.lblNumero.Name = "lblNumero";
            this.lblNumero.Size = new System.Drawing.Size(41, 45);
            this.lblNumero.TabIndex = 14;
            this.lblNumero.Text = "X";
            // 
            // cbxCarro
            // 
            this.cbxCarro.FormattingEnabled = true;
            this.cbxCarro.Location = new System.Drawing.Point(3, 72);
            this.cbxCarro.Name = "cbxCarro";
            this.cbxCarro.Size = new System.Drawing.Size(248, 23);
            this.cbxCarro.TabIndex = 15;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.cbxConcessionaria);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.cbxCliente);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblNomeDoCarro);
            this.panel1.Location = new System.Drawing.Point(26, 108);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(442, 332);
            this.panel1.TabIndex = 13;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(20)))), ((int)(((byte)(255)))));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(85, 185);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(298, 123);
            this.button1.TabIndex = 5;
            this.button1.Text = "Vender";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cbxConcessionaria
            // 
            this.cbxConcessionaria.FormattingEnabled = true;
            this.cbxConcessionaria.Location = new System.Drawing.Point(145, 129);
            this.cbxConcessionaria.Name = "cbxConcessionaria";
            this.cbxConcessionaria.Size = new System.Drawing.Size(293, 23);
            this.cbxConcessionaria.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(20)))), ((int)(((byte)(255)))));
            this.label2.Location = new System.Drawing.Point(3, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(145, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Concessionaria";
            // 
            // cbxCliente
            // 
            this.cbxCliente.FormattingEnabled = true;
            this.cbxCliente.Location = new System.Drawing.Point(106, 88);
            this.cbxCliente.Name = "cbxCliente";
            this.cbxCliente.Size = new System.Drawing.Size(293, 23);
            this.cbxCliente.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(20)))), ((int)(((byte)(255)))));
            this.label1.Location = new System.Drawing.Point(22, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Cliente:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblNomeDoCarro
            // 
            this.lblNomeDoCarro.AutoSize = true;
            this.lblNomeDoCarro.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNomeDoCarro.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(20)))), ((int)(((byte)(255)))));
            this.lblNomeDoCarro.Location = new System.Drawing.Point(22, 24);
            this.lblNomeDoCarro.Name = "lblNomeDoCarro";
            this.lblNomeDoCarro.Size = new System.Drawing.Size(79, 45);
            this.lblNomeDoCarro.TabIndex = 0;
            this.lblNomeDoCarro.Text = "XYZ";
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(789, 688);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelCarros);
            this.Controls.Add(this.panelBtn);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormPrincipal";
            this.Text = "s";
            this.Load += new System.EventHandler(this.FormPrincipal_Load);
            this.panelBtn.ResumeLayout(false);
            this.panelCarros.ResumeLayout(false);
            this.panelCarros.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Button btn10;
        private Button btn6;
        private Button btn5;
        private Button btn3;
        private Button btn1;
        private Button btn2;
        private Button btn4;
        private Button btn7;
        private Button btn9;
        private Button btn8;
        private Button btn11;
        private Panel panelBtn;
        private Panel panelCarros;
        private Button btnEscolher;
        private Label lblarea;
        private Label lblCarro;
        private Label lblNumero;
        private ComboBox cbxCarro;
        private Panel panel1;
        private Label lblNomeDoCarro;
        private Label label1;
        private ComboBox cbxCliente;
        private ComboBox cbxConcessionaria;
        private Label label2;
        private Button button1;
    }
}